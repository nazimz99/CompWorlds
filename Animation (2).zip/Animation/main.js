function Animation(spriteSheet, startX, startY, frameWidth, frameHeight, sheetWidth, frameDuration, frames, loop, reverse) {
    this.spriteSheet = spriteSheet;
    this.startX = startX;
    this.startY = startY;
    this.frameWidth = frameWidth;
    this.frameDuration = frameDuration;
    this.frameHeight = frameHeight;
    this.sheetWidth = sheetWidth;
    this.frames = frames;
    this.totalTime = frameDuration * frames;
    this.elapsedTime = 0;
    this.loop = loop;
    this.reverse = reverse;
}

Animation.prototype.drawFrame = function (tick, ctx, x, y) {
    var scaleBy = scaleBy || 1;
    this.elapsedTime += tick;
    if (this.loop) {
        this.elapsedTime = 0;
    } 
    var frame = this.currentFrame();
    var xindex = 0;
    var yindex = 0;
    xindex = frame % this.sheetWidth;
    yindex = Math.floor(frame / this.sheetWidth);

    ctx.drawImage(this.spriteSheet,
                 xindex * this.frameWidth, yindex * this.frameHeight,  // source from sheet
                 this.frameWidth, this.frameHeight,
                 x, y,
                 this.frameWidth * this.scale,
                 this.frameHeight * this.scale);

    var index = this.reverse ? this.frames - this.currentFrame() - 1 : this.currentFrame();
    var vindex = 0;
    if ((index + 1) * this.frameWidth + this.startX > this.spriteSheet.width) {
        index -= Math.floor((this.spriteSheet.width - this.startX) / this.frameWidth);
        vindex++;
    }
    while ((index + 1) * this.frameWidth > this.spriteSheet.width) {
        index -= Math.floor(this.spriteSheet.width / this.frameWidth);
        vindex++;
    }

    var locX = x;
    var locY = y;
    var offset = vindex === 0 ? this.startX : 0;
    ctx.drawImage(this.spriteSheet,
                  index * this.frameWidth + offset, vindex * this.frameHeight + this.startY,  // source from sheet
                  this.frameWidth, this.frameHeight,
                  locX, locY,
                  this.frameWidth * scaleBy,
                  this.frameHeight * scaleBy); 
}

Animation.prototype.currentFrame = function () {
    return Math.floor(this.elapsedTime / this.frameDuration);
}

Animation.prototype.isDone = function () {
    return (this.elapsedTime >= this.totalTime);
}

function Background(game, spritesheet) {
    //Entity.call(this, game, 0, 400);
    this.x = 0;
    this.y = 0;
    this.spritesheet = spritesheet;
    this.game = game;
    this.ctx = game.ctx;
}

Background.prototype = new Entity();
Background.prototype.constructor = Background;

Background.prototype.update = function () {
}

Background.prototype.draw = function () {
    this.ctx.drawImage(this.spritesheet, this.x, this.y);
    /*ctx.fillStyle = "SaddleBrown";
    ctx.fillRect(0,500,800,300);
    Entity.prototype.draw.call(this);*/
}

function Swordsman(game) {
    this.walkRight = new Animation(ASSET_MANAGER.getAsset("./img/SwordWalkRight.png"), 0, 0, 27.75, 44, 4, 0.09, 30, true, false); //27.75,44
    this.walkLeft = new Animation(ASSET_MANAGER.getAsset("./img/SwordWalkLeft.png"), 0, 0, 28.5, 45, 4, 0.09, 30, true, true); //28.5,45
    this.runRight =  new Animation(ASSET_MANAGER.getAsset("./img/SwordRunRight.png"), 0, 0, 38.75, 43, 4, 0.09, 30, true, false);//38.75, 43
    this.runLeft = new Animation(ASSET_MANAGER.getAsset("./img/SwordRunLeft.png"), 0, 0, 39.5, 38, 4, 0.09, 30, true, true);//39.5, 38
    this.slashRight = new Animation(ASSET_MANAGER.getAsset("./img/SwordSlashRight.png"), 0, 0, 82.5714, 50, 7, 0.09, 30, true, false);//82.5714, 50
    this.slashLeft = new Animation(ASSET_MANAGER.getAsset("./img/SwordSlashLeft.png"), 0, 0, 83.286, 50, 7, 0.09, 30, true, true);//83.286, 50
    
    this.ctx = game.ctx;
    this.speed = 50;
    this.walkingRight = false;
    this.walkingLeft = false;
    this.runningRight = false;
    this.runningLeft = false;
    this.slashingRight = false;
    this.slashingLeft = false;
    this.attack = false;
    this.radius = 100;
    //this.ground = 400;
    Entity.call(this, game, 0, 200);
}

Swordsman.prototype = new Entity(this.game, 0, 600);
Swordsman.prototype.constructor = Swordsman;

Swordsman.prototype.WalkRight = function() {
    if (this.walkingRight) {
        this.speed = 50;
        if (this.walkRight.isDone() || this.x >= 800) {
            this.walkRight.elapsedTime = 0;
            this.walkingRight = false;
        }
        this.x += this.game.clockTick * this.speed;
        if (this.x > 800) this.x = -230;
        Swordsman.prototype.draw = function(ctx) {
            this.walkRight.drawFrame(this.game.clockTick, ctx, this.x, this.y);
            Entity.prototype.draw.call(this);
        }
    }
}

Swordsman.prototype.WalkLeft = function() {
    if (this.walkingLeft) {
        this.speed = 50;
        if (this.walkLeft.isDone() || this.x <= 0) {
            this.walkLeft.elapsedTime = 0;
            this.walkingLeft = false;
        }
        this.x -= this.game.clockTick * this.speed;
        if (this.x > 800) this.x = -230;
        Swordsman.prototype.draw = function(ctx) {
            this.walkLeft.drawFrame(this.game.clockTick, ctx, this.x, this.y);
            Entity.prototype.draw.call(this);
        }
    }
}

Swordsman.prototype.RunRight = function() {
    this.speed = 100;
    if (this.runningRight) {
        if (this.runLeft.isDone() || this.x <= 0) {
            this.runRight.elapsedTime = 0;
            this.runningRight = false;
        }
        this.x += this.game.clockTick * this.speed;
        if (this.x < 0) this.x = 1030;
        Swordsman.prototype.draw = function(ctx) {
            this.runRight.drawFrame(this.game.clockTick, ctx, this.x, this.y);
            Entity.prototype.draw.call(this);
        }
    }
}

Swordsman.prototype.RunLeft = function() {
    if (this.runningLeft) {
        this.speed = 100;
        if (this.runLeft.isDone() || this.x <= 0) {
            this.runLeft.elapsedTime = 0;
            this.runningLeft = false;
        }
        this.x -= this.game.clockTick * this.speed;
        if (this.x < 0) this.x = 1030;
        Swordsman.prototype.draw = function(ctx) {
            this.runLeft.drawFrame(this.game.clockTick, ctx, this.x, this.y);
            Entity.prototype.draw.call(this);
        }
    }
}

Swordsman.prototype.SlashRight = function() {
    if (this.slashingRight) {
        if (this.slashRight.isDone()) {
            this.slashRight.elapsedTime = 0;
            this.slashRight = false;
        }
        Swordsman.prototype.draw = function(ctx) {
            this.slashRight.drawFrame(this.game.clockTick, ctx, this.x, this.y);
            Entity.prototype.draw.call(this);
        }
    }
}

Swordsman.prototype.SlashLeft = function() {
    if (this.slashingLeft) {
        if (this.slashLeft.isDone()) {
            this.slashLeft.elapsedTime = 0;
            this.slashLeft = false;
        }
        Swordsman.prototype.draw = function(ctx) {
            this.slashLeft.drawFrame(this.game.clockTick, ctx, this.x, this.y);
            Entity.prototype.draw.call(this);
        }
    }
}

Swordsman.prototype.update = function () {
    if (this.game.space) {
        if(this.x >= 800) this.walkingLeft = true;
        else if (this.x <= 0) this.walkingRight = true;
        else
            this.walkingRight = true;

        this.walkingRight = true;
        this.WalkRight();
        this.runningRight = true;
        this.RunRight();
        this.walkingLeft = true;
        this.WalkLeft();
        this.runningLeft = true;
        this.RunLeft();
        console.log(this.x);
        if (x === 400 && Math.random() > 0.5) {
            this.walkLeft.elapsedTime = 0;
            this.walkRight.elapsedTime = 0;
            this.runLeft.elapsedTime = 0;
            this.runRight.elapsedTime = 0;
            this.attack = true;
        }
        if (this.attack) {
            var chance = Math.random();
            if (chance < 0.5) slashingRight = true;
            else slashingLeft = true;
            this.SlashLeft();
            this.SlashRight();
            this.attack = false;
        }   

        /*var jumpDistance = this.jumpAnimation.elapsedTime / this.jumpAnimation.totalTime;
        var totalHeight = 200;

        if (jumpDistance > 0.5)
            jumpDistance = 1 - jumpDistance;

        //var height = jumpDistance * 2 * totalHeight;
        var height = totalHeight*(-4 * (jumpDistance * jumpDistance - jumpDistance));
        //this.y = this.ground - height; 
        this.x += this.game.clockTick * this.speed;
        if (this.x > 800) this.x = -230; */
    }
    Entity.prototype.update.call(this);
}

function Dedede(game) {
    this.flyRight = new Animation(ASSET_MANAGER.getAsset("./img/DededeRight.png"), 3, 8, 104.8, 87.4667, 0.02, 30, true, true); //3,8
    this.flyLeft = new Animation(ASSET_MANAGER.getAsset("./img/DededeLeft.png"), 0, 8, 104.8, 87.4667, 0.02, 30, true, true); // 3,8
    this.fallRight = new Animation(ASSET_MANAGER.getAsset("./img/DededeRight.png"), 0, 9, 104.8, 87.4667, 0.02, 30, true, true); //3, 9
    this.fallLeft = new Animation(ASSET_MANAGER.getAsset("./img/DededeLeft.png"), 0, 9, 104.8, 87.4667, 0.02, 30, true, true);
    
    this.ctx = game.ctx;
    this.flyingRight = false;
    this.flyingLeft = false;
    this.fallingRight = false;
    this.fallingLeft = false;
    this.radius = 100;
    this.ground = 0;
    Entity.call(this, game, 0, 200);
}

Dedede.prototype = new Entity(this.game, 20, 600);
Dedede.prototype.constructor = Dedede;

Dedede.prototype.FlyRight = function() {
    if (this.flyingRight && this.flyLeft.elapsedTime === 0) {
        if (this.flyRight.isDone() || this.x >= 800 || this.y === totalHeight) {
            this.flyRight.elapsedTime = 0;
            this.flyingRight = false;
        }
        var jumpDistance = this.flyRight.elapsedTime / this.flyLeft.totalTime;
        var totalHeight = 400;
        var distance = 400;
        if (jumpDistance > 0.5) jumpDistance = 1 - jumpDistance;
        var height = totalHeight * (-4 * (jumpDistance * jumpDistance - jumpDistance));
        this.y += height;
        this.x += distance * jumpDistance * this.gameClockTick;
    }
}

Dedede.prototype.FlyLeft = function() {
    if (this.flyingLeft && this.flyRight.elapsedTime === 0) {
        if (this.flyLeft.isDone() || this.x <= 0 || this.y === totalHeight) {
            this.flyLeft.elapsedTime = 0;
            this.flyingLeft = false;
        }
        var jumpDistance = this.flyLeft.elapsedTime / this.flyLeft.totalTime;
        var totalHeight = 400;
        var distance = 400;
        if (jumpDistance > 0.5) jumpDistance = 1 - jumpDistance;
        var height = totalHeight * (-4 * (jumpDistance * jumpDistance - jumpDistance));
        this.y += height;
        this.x -= distance * jumpDistance * this.gameClockTick;
    }

}

Dedede.prototype.FallRight = function() {
    if (this.fallingRight && this.fallLeft.elapsedTime === 0) {
        if (this.fallRight.isDone()) {
            this.fallRight.elapsedTime = 0;
            this.fallingRight = false;
        }
    }
    var jumpDistance = this.fallRight.elapsedTime / this.fallRight.totalTime;
    var totalFall = 400;
    var distance = 400;
    if (jumpDistance > 0.5) jumpDistance = 1 - jumpDistance;
    var height = totalFall * (-4 * (jumpDistance * jumpDistance - jumpDistance));
    this.y -= height;
    this.x += distance * jumpDistance * this.gameClockTick;
}

Dedede.prototype.FallLeft = function() {
    if (this.fallingLeft && this.fallRight.elapsedTime === 0) {
        if (this.fallLeft.isDone()) {
            this.fallLeft.elapsedTime = 0;
            this.fallingLeft = false;
        }
    }
    var jumpDistance = this.fallRight.elapsedTime / this.fallRight.totalTime;
    var totalFall = 400;
    var distance = 400;
    if (jumpDistance > 0.5) jumpDistance = 1 - jumpDistance;
    var height = totalFall * (-4 * (jumpDistance * jumpDistance - jumpDistance));
    this.y -= height;
    this.x -= distance * jumpDistance * this.gameClockTick;
}

Dedede.prototype.draw = function() {
    if (this.flyingRight) this.flyRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    if (this.flyingLeft) this.flyLeft.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    if (this.fallingRight) this.fallRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    if (this.fallingLeft) this.fallLeft.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    Entity.prototype.draw.call(this);
}

Dedede.prototype.update = function() {
    if (this.game.space) {
        if(this.x >= 800) this.flyingLeft = true;
        else if (this.x <= 0) this.flyingRight = true;
        else
            this.flyingRight = true;

        this.FlyRight();
        this.fallingRight = true;
        this.FallRight();
        this.FlyingLeft = true;
        this.FlyLeft();
        this.FallingLeft = true;
        this.FallLeft();
        Entity.prototype.update.call(this);
    }
}
// the "main" code begins here

var ASSET_MANAGER = new AssetManager();

ASSET_MANAGER.queueDownload("./img/SwordWalkRight.png");
ASSET_MANAGER.queueDownload("./img/SwordWalkLeft.png");
ASSET_MANAGER.queueDownload("./img/SwordRunRight.png");
ASSET_MANAGER.queueDownload("./img/SwordRunLeft.png");
ASSET_MANAGER.queueDownload("./img/SwordSlashRight.png");
ASSET_MANAGER.queueDownload("./img/SwordSlashLeft.png");
ASSET_MANAGER.queueDownload("./img/background.png");
ASSET_MANAGER.queueDownload("./img/DededeRight.png");
ASSET_MANAGER.queueDownload("./img/DededeLeft.png");

ASSET_MANAGER.downloadAll(function () {
    var canvas = document.getElementById('gameWorld');
    var ctx = canvas.getContext('2d');
    var gameEngine = new GameEngine();
    gameEngine.init(ctx);
    gameEngine.start();

    var bg = new Background(gameEngine, ASSET_MANAGER.getAsset("./img/background.png"));
    var swordsman = new Swordsman(gameEngine);
    var dedede = new Dedede(gameEngine);

    gameEngine.addEntity(bg);
    gameEngine.addEntity(swordsman);
    /*gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordWalkLeft.png"));
    //gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordRunRight.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordRunLeft.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordSlashRight.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordSlashLeft.png"));*/
    gameEngine.addEntity(dedede); //ASSET_MANAGER.getAsset("./img/DededeRight.png"), ASSET_MANAGER.getAsset("./img/DededeLeft.png"));
    console.log(swordsman.walkingRight);


});
