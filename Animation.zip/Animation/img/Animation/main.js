function Animation(spriteSheet, startX, startY, frameWidth, frameHeight, frameDuration, frames, loop, reverse) {
    this.spriteSheet = spriteSheet;
    this.startX = startX;
    this.startY = startY;
    this.frameWidth = frameWidth;
    this.frameDuration = frameDuration;
    this.frameHeight = frameHeight;
    this.frames = frames;
    this.totalTime = frameDuration * frames;
    this.elapsedTime = 0;
    this.loop = loop;
    this.reverse = reverse;
}

Animation.prototype.drawFrame = function (tick, ctx, x, y) {
    var scaleBy = scaleBy || 1;
    this.elapsedTime += tick;
    if (this.loop) {
        if (this.isDone()) this.elapsedTime = 0;
    } 
    var frame = this.currentFrame();
    var xindex = 0;
    var yindex = 0;
    xindex = frame % this.sheetWidth;
    yindex = Math.floor(frame / this.sheetWidth);

    ctx.drawImage(this.spriteSheet,
                 xindex * this.frameWidth, yindex * this.frameHeight,  // source from sheet
                 this.frameWidth, this.frameHeight,
                 x, y,
                 this.frameWidth * this.scale,
                 this.frameHeight * this.scale);

    /*var index = this.reverse ? this.frames - this.currentFrame() - 1 : this.currentFrame();
    var vindex = 0;
    if ((index + 1) * this.frameWidth + this.startX > this.spriteSheet.width) {
        index -= Math.floor((this.spriteSheet.width - this.startX) / this.frameWidth);
        vindex++;
    }
    while ((index + 1) * this.frameWidth > this.spriteSheet.width) {
        index -= Math.floor(this.spriteSheet.width / this.frameWidth);
        vindex++;
    }

    var locX = x;
    var locY = y;
    var offset = vindex === 0 ? this.startX : 0;
    ctx.drawImage(this.spriteSheet,
                  index * this.frameWidth + offset, vindex * this.frameHeight + this.startY,  // source from sheet
                  this.frameWidth, this.frameHeight,
                  locX, locY,
                  this.frameWidth * scaleBy,
                  this.frameHeight * scaleBy); */
}

Animation.prototype.currentFrame = function () {
    return Math.floor(this.elapsedTime / this.frameDuration);
}

Animation.prototype.isDone = function () {
    return (this.elapsedTime >= this.totalTime);
}

function Background(game, spritesheet) {
    Entity.call(this, game, 0, 400);
    this.x = 0;
    this.y = 0;
    this.spritesheet = spritesheet;
    this.game = game;
    this.ctx = game.ctx;
}

Background.prototype = new Entity(this.game, 0, 0);
Background.prototype.constructor = Background;

Background.prototype.update = function () {
}

Background.prototype.draw = function () {
    this.ctx.drawImage(this.spritesheet, this.x, this.y);
    /*ctx.fillStyle = "SaddleBrown";
    ctx.fillRect(0,500,800,300);
    Entity.prototype.draw.call(this);*/
}

function Swordsman(game) {
    this.walkRight = new Animation(ASSET_MANAGER.getAsset("./Animation/SwordWalkRight.png"), 0, 0, 39.5, 38, 0.02, 30, true, true);
    this.walkLeft = new Animation(ASSET_MANAGER.getAsset("./Animation/SwordWalkLeft.png"), 0, 0, 39.5, 38, 0.02, 30, true, true);
    this.runRight =  new Animation(ASSET_MANAGER.getAsset("./Animation/SwordRunRight.png"), 0, 0, 28.5, 45, 0.02, 30, true, true);
    this.runLeft = new Animation(ASSET_MANAGER.getAsset("./Animation/SwordRunLeft.png"), 0, 0, 28.5, 45, 0.02, 30, true, true);
    this.slashRight = new Animation(ASSET_MANAGER.getAsset("./Animation/SwordSlashRight.png"), 0, 0, 82.5714, 50, 0.02, 30, true, true);
    this.slashLeft = new Animation(ASSET_MANAGER.getAsset("./Animation/SwordSlashLeft.png"), 0, 0, 82.5714, 50, 0.02, 30, true, true);
    
    this.ctx = game.ctx;
    this.reverse = game.ctx.reverse();
    this.speed = null;
    this.walkingRight = false;
    this.walkingLeft = false;
    this.runningRight = false;
    this.runningLeft = false;
    this.slashingRight = false;
    this.slashingLeft = false;
    this.attack = false;
    //this.radius = 100;
    //this.ground = 400;
    Entity.call(this, game, 0, 400);
}

Swordsman.prototype = new Entity(this.game, 0, 400);
Swordsman.prototype.constructor = Swordsman;

Swordsman.prototype.walkRight = function() {
    if (this.walkingRight && this.walkLeft.elapsedTime === 0) {
        this.speed = 50;
        if (this.walkRight.isDone() || this.x >= 800) {
            this.walkRight.elapsedTime = 0;
            this.walkingRight = false;
        }
        this.x += this.game.clockTick * this.speed;
        if (this.x > 800) this.x = -230;
    }
}

Swordsman.prototype.walkLeft = function() {
    if (this.walkingLeft && this.walkRight.elapsedTime === 0) {
        this.speed = 50;
        if (this.walkLeft.isDone() || this.x <= 0) {
            this.walkLeft.elapsedTime = 0;
            this.walkingLeft = false;
        }
        this.x -= this.game.clockTick * this.speed;
        if (this.x > 800) this.x = -230;
    }
}

Swordsman.prototype.runRight = function() {
    this.speed = 100;
    if (this.runningRight && this.runLeft.elapsedTime === 0)
        if (this.runLeft.isDone() || this.x <= 0) {
            this.runRight.elapsedTime = 0;
            this.runningRight = false;
        }
        this.x -= this.game.clockTick * this.speed;
        if (this.x < 0) this.x = 1030;
}

Swordsman.prototype.runLeft = function() {
    if (this.runningLeft && this.runRight.elapsedTime === 0) {
        this.speed = 100;
        if (this.runLeft.isDone() || this.x <= 0) {
            this.runLeft.elapsedTime = 0;
            this.runningLeft = false;
        }
        this.x -= this.game.clockTick * this.speed;
        if (this.x < 0) this.x = 1030;
    }
}

Swordsman.prototype.slashRight = function() {
    if (slashingRight && this.slashLeft.elapsedTime === 0) {
        if (this.slashRight.isDone()) {
            this.slashRight.elapsedTime = 0;
            this.slashRight = false;
        }
    }
}

Swordsman.prototype.slashLeft = function() {
    if (slashingLeft && this.slashRight.elapsedTime === 0) {
        if (this.slashLeft.isDone()) {
            this.slashLeft.elapsedTime = 0;
            this.slashLeft = false;
        }
    }
}

Swordsman.prototype.update = function () {
    if (this.game.space) 
        if(this.x >= 800) this.walkingLeft = true;
        else if (this.x <= 0) this.walkingRight = true;
        else
            this.walkingRight = true;

        this.walkRight();
        this.runningRight = true;
        this.runRight();
        this.walkingLeft = true;
        this.walkLeft();
        this.runningLeft = true;
        this.runLeft();

        if (x === 400 && Math.random() > 0.5) {
            this.walkLeft.elapsedTime = 0;
            this.walkRight.elapsedTime = 0;
            this.runLeft.elapsedTime = 0;
            this.runRight.elapsedTime = 0;
            this.attack = true;
        }
        if (this.attack) {
            var chance = Math.random();
            if (chance < 0.5) slashingRight = true;
            else slashingLeft = true;
            this.slashLeft();
            this.slashRight();
        }   

        /*var jumpDistance = this.jumpAnimation.elapsedTime / this.jumpAnimation.totalTime;
        var totalHeight = 200;

        if (jumpDistance > 0.5)
            jumpDistance = 1 - jumpDistance;

        //var height = jumpDistance * 2 * totalHeight;
        var height = totalHeight*(-4 * (jumpDistance * jumpDistance - jumpDistance));
        //this.y = this.ground - height; 
        this.x += this.game.clockTick * this.speed;
        if (this.x > 800) this.x = -230; */
    Entity.prototype.update.call(this);
}

Swordsman.prototype.draw = function () {
    /*if (this.jumping) {
        this.jumpAnimation.drawFrame(this.game.clockTick, ctx, this.x + 17, this.y - 34);
    }
    else {
        this.animation.drawFrame(this.game.clockTick, ctx, this.x, this.y);
    }*/
    if (this.walkingRight) this.walkRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    if (this.walkingLeft) this.walkLeft.drawFrame(this.game.clockTick, this.reverse, this.x, this.y);
    if (this.runningRight) this.runRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    if (this.runningLeft) this.runLeft.drawFrame(this.game.clockTick, this.reverse, this.x, this.y);
    if (this.slashingRight) this.slashRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    if (this.slashingLeft) this.slashLeft.drawFrame(this.game.clockTick, this.reverse, this.x, this.y);
    Entity.prototype.draw.call(this);
}

function Dedede(game) {
    this.flyRight = new Animation(ASSET_MANAGER.getAsset("./img/DededeRight.png"), 3, 8, 104.8, 87.4667, 0.02, 30, true, true);
    this.flyLeft = new Animation(ASSET_MANAGER.getAsset("./img/DededeLeft.png"), 3, 8, 104.8, 87.4667, 0.02, 30, true, true);
    this.fallRight = new Animation(ASSET_MANAGER.getAsset("./img/DededeRight.png"), 3, 9, 104.8, 87.4667, 0.02, 30, true, true);
    this.fallLeft = new Animation(ASSET_MANAGER.getAsset("./img/DededeLeft.png"), 3, 9, 104.8, 87.4667, 0.02, 30, true, true);
    
    this.ctx = game.ctx;
    this.reverse = game.ctx.reverse();
    this.flyingRight = false;
    this.flyingLeft = false;
    this.fallingRight = false;
    this.fallingLeft = false;
}

Dedede.prototype = new Entity(this.game, 0, 800);
Dedede.prototype.constructor = Dedede;

Dedede.prototype.update = function() {
}

Dedede.prototype.flyRight = function() {
    if (this.flyingRight && this.flyLeft.elapsedTime === 0) {
        this.speed = 80;
        if (this.flyRight.isDone() || this.x >= 800) {
            this.flyRight.elapsedTime = 0;
            this.flyingRight = false;
        }
        this.x += this.game.clockTick * this.speed;
        if (this.x > 800) this.x = -230;
    }
}

Dedede.prototype.flyLeft = function() {
    if (this.flyingLeft && this.flyLeft.elapsedTime === 0) {
        this.speed = 80;
        if (this.flyLeft.isDone() || this.x <= 0) {
            this.flyLeft.elapsedTime = 0;
            this.flyingLeft = false;
        }
        this.x -= this.game.clockTick * this.speed;
        if (this.x < 0) this.x = 1030;
    }
}
// the "main" code begins here

var ASSET_MANAGER = new AssetManager();

ASSET_MANAGER.queueDownload("./img/SwordWalkRight.png");
ASSET_MANAGER.queueDownload("./img/SwordWalkLeft.png");
ASSET_MANAGER.queueDownload("./img/SwordRunRight.png");
ASSET_MANAGER.queueDownload("./img/SwordRunLeft.png");
ASSET_MANAGER.queueDownload("./img/SwordSlashRight.png");
ASSET_MANAGER.queueDownload("./img/SwordSlashLeft.png");
ASSET_MANAGER.queueDownload("./img/background.png");

ASSET_MANAGER.downloadAll(function () {
    var canvas = document.getElementById('gameWorld');
    var ctx = canvas.getContext('2d');
    var gameEngine = new GameEngine();
    gameEngine.init(ctx);
    gameEngine.start();

    var bg = new Background(gameEngine, ASSET_MANAGER.getAsset("./img/background.png"));
    var swordsman = new Swordsman(gameEngine);

    gameEngine.addEntity(bg, ASSET_MANAGER.getAsset("./img/background.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordWalkRight.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordWalkLeft.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordRunRight.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordRunLeft.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordSlashRight.png"));
    gameEngine.addEntity(swordsman, ASSET_MANAGER.getAsset("./img/SwordSlashLeft.png"));
 
});
