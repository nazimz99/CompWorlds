var ASSET_MANAGER = new AssetManager();

function Animation(spriteSheet, startX, startY, frameWidth, frameHeight, sheetWidth, frameDuration, frames, loop, reverse) {
    this.spriteSheet = spriteSheet;
    this.startX = startX;
    this.startY = startY;
    this.frameWidth = frameWidth;
    this.frameDuration = frameDuration;
    this.frameHeight = frameHeight;
    this.sheetWidth = sheetWidth;
    this.frames = frames;
    this.totalTime = frameDuration * frames;
    this.elapsedTime = 0;
    this.loop = loop;
    this.reverse = reverse;
}

Animation.prototype.drawFrame = function (tick, ctx, x, y) {
    var scaleBy = scaleBy || 1;
    this.elapsedTime += tick;
    if (this.loop) {
        this.elapsedTime = 0;
    } 
    var frame = this.currentFrame();
    var xindex = 0;
    var yindex = 0;
    xindex = frame % this.sheetWidth;
    yindex = Math.floor(frame / this.sheetWidth);

    ctx.drawImage(this.spriteSheet,
                 xindex * this.frameWidth, yindex * this.frameHeight,  // source from sheet
                 this.frameWidth, this.frameHeight,
                 x, y,
                 this.frameWidth * this.scale,
                 this.frameHeight * this.scale);

    var index = this.reverse ? this.frames - this.currentFrame() - 1 : this.currentFrame();
    var vindex = 0;
    if ((index + 1) * this.frameWidth + this.startX > this.spriteSheet.width) {
        index -= Math.floor((this.spriteSheet.width - this.startX) / this.frameWidth);
        vindex++;
    }
    while ((index + 1) * this.frameWidth > this.spriteSheet.width) {
        index -= Math.floor(this.spriteSheet.width / this.frameWidth);
        vindex++;
    }

    var locX = x;
    var locY = y;
    var offset = vindex === 0 ? this.startX : 0;
    ctx.drawImage(this.spriteSheet,
                  index * this.frameWidth + offset, vindex * this.frameHeight + this.startY,  // source from sheet
                  this.frameWidth, this.frameHeight,
                  locX, locY,
                  this.frameWidth * scaleBy,
                  this.frameHeight * scaleBy); 
}

Animation.prototype.currentFrame = function () {
    return Math.floor(this.elapsedTime / this.frameDuration);
}

Animation.prototype.isDone = function () {
    return (this.elapsedTime >= this.totalTime);
}

function Background(game, spritesheet) {
    this.x = 0;
    this.y = 0;
    this.spritesheet = spritesheet;
    this.game = game;
    this.ctx = game.ctx;
};

Background.prototype = new Entity();
Background.prototype.constructor = Background;

Background.prototype.update = function () {
};

Background.prototype.draw = function () {
    this.ctx.drawImage(this.spritesheet,
                   this.x, this.y);
};


function Swordsman(game) {
    this.walkRight = new Animation(ASSET_MANAGER.getAsset("./img/SwordWalk.png"), 0, 0, 27.75, 44, 4, 0.09, 30, true, false); //27.75,44
    this.walkLeft = new Animation(ASSET_MANAGER.getAsset("./img/SwordWalk.png"), 0, 0, 27.75, 44, 4, 0.09, 30, true, true); //28.5,45
    this.runRight =  new Animation(ASSET_MANAGER.getAsset("./img/SwordRun.png"), 0, 0, 38.75, 43, 4, 0.09, 30, true, false);//38.75, 43
    this.runLeft = new Animation(ASSET_MANAGER.getAsset("./img/SwordRun.png"), 0, 0, 38.75, 43, 4, 0.09, 30, true, true);//39.5, 38
    this.slashRight = new Animation(ASSET_MANAGER.getAsset("./img/SwordSlash.png"), 0, 0, 82.5714, 50, 7, 0.09, 30, true, false);//82.5714, 50
    this.slashLeft = new Animation(ASSET_MANAGER.getAsset("./img/SwordSlash.png"), 0, 0, 82.5714, 50, 7, 0.09, 30, true, true);//83.286, 50
    this.x = 0;
    this.y = 0;
    this.walkingRight = false;
    this.walkingLeft = false;
    this.runningRight = false;
    this.runningLeft = false;
    this.slashingRight = false;
    this.slashingLeft = false;
    this.speed = null;
    this.game = game;
    this.ctx = game.ctx;
    Entity.call(this, game, 0, 200);
}

Swordsman.prototype = new Entity();
Swordsman.prototype.constructor = Swordsman;

Swordsman.prototype.draw = function () {
    if (this.walkingRight) this.walkRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    else if (this.walkingLeft) this.walkLeft.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    else if (this.runningRight) this.runningRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    else if (this.runningLeft) this.runningLeft.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    else if (this.slashRight) this.slashRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    else if (this.slashLeft) this.slashLeft.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
}

Swordsman.prototype.update = function () {
    if(this.x >= 800) this.walkingLeft = true;
        else if (this.x <= 0) this.walkingRight = true;
        else
            this.walkingRight = true;
    
    if (this.walkingRight) {
        this.speed = 50;
        this.x += this.gameClockTick * this.speed;
        if (this.x === 400) {
            this.walkingRight = false;
            this.runningRight = true;
        }
    }
    if (this.runningRight) {
        this.speed = 100;
        this.x += this.gameClockTick * this.speed;
        if (this.x === 800) {
            this.runningRight = false;
            this.walkingLeft = true;
        }
    }
    if (this.walkingLeft) {
        this.speed = 50;
        this.x -= this.gameClockTick * this.speed;
        if (this.x === 400) {
            this.walkingLeft = false;
            this.runningLeft = true;
        }
    }
    if (this.runningLeft) {
        this.speed = 100;
        this.x -= this.gameClockTick * this.speed;
        if (this.x === 200) {
            this.runningLeft = false;
            this.slashingLeft = true;
        }
    }
    if (this.slashingLeft) {
        this.slashingLeft = false;
        this.slashingRight = true;
    }

    /*f (this.animation.elapsedTime < this.animation.totalTime * 8 / 14)
        this.x += this.game.clockTick * this.speed;
    if (this.x > 800) this.x = -230;*/
    Entity.prototype.update.call(this);
}

function Dedede(game) {
    this.flyRight = new Animation(ASSET_MANAGER.getAsset("./img/DededeFly"), 0, 0, 76.4, 85, 10, 2, 0.05, 8, true, false, 0.5);
    this.flyLeft = new Animation(ASSET_MANAGER.getAsset("./img/DededeFly"), 9, 0, 76.4, 85, 10, 2, 0.05, 8, true, true, 0.5);
    this.fallRight = new Animation(ASSET_MANAGER.getAsset("./img/DededeFall"), 0, 0, 80.5, 84.1667, 6, 2, 0.05, 8, true, false, 0.5);
    this.fallLeft = new Animation(ASSET_MANAGER.getAsset("./img/DededeFall"), 5, 0, 80.5, 84.1667, 6, 2, 0.05, 8, true, true, 0.5);
    this.x = 0;
    this.y = 0;
    this.flyingRight = false;
    this.flyingLeft = false;
    this.fallingRight = false;
    this.fallingLeft = false;
    this.ground = 200;
    this.ctx = game.ctx;
    Entity.call(this, game, 0, 600);
}

Dedede.prototype = new Entity();
Dedede.prototype.constructor = Dedede;

Dedede.prototype.update = function () {
    if (this.x < 800) this.flyingRight = true;
    else this.flyingLeft = true;

    var totalHeight = 400;
    var height = totalHeight *(-4 * (flyDistance * flyDistance - flyDistance));
    var flyDistance = this.flyRight.elapsedTime / this.flyRight.totalTime;
    if (flyDistance > 0.5) flyDistance = 1 - flyDistance;
    if (this.flyingRight) {
        if (this.flyRight.isDone()) {
            this.flyRight.elapsedTime = 0;
            this.flyRight = false;
            this.fallingRight = true;
        }
        this.y = this.ground + height;
        this.x += 200;
    }
    if (this.flyingLeft) {
        if (this.flyLeft.isDone()) {
            this.flyLeft.elapsedTime = 0;
            this.flyLeft = false;
            this.fallingLeft = true;
        }
        this.y = this.ground + height;
        this.x -= 200;
    }
    if (this.fallingRight) {
        if (this.fallRight.isDone()) {
            this.fallRight.elapsedTime = 0;
            this.fallingRight = false;
        }
        this.y = this.ground - height;
        this.x += 200;
    }
    if (this.fallingLeft) {
        if (this.fallLeft.isDone()) {
            this.fallLeft.elapsedTime = 0;
            this.fallingLeft = false;
        }
        this.y = this.ground - height;
        this.x -= 200;
    }
    Entity.prototype.update.call(this);
}

Dedede.prototype.draw = function () {
    if (this.flyingRight) this.flyRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    else if (this.flyingLeft) this.flyingLeft.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    else if (this.fallingRight) this.fallingRight.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    else if (this.fallingLeft) this.fallingLeft.drawFrame(this.game.clockTick, this.ctx, this.x, this.y);
    Entity.prototype.draw.call(this);
}


ASSET_MANAGER.queueDownload("./img/SwordWalk.png");
ASSET_MANAGER.queueDownload("./img/SwordRun.png");
ASSET_MANAGER.queueDownload("./img/SwordSlash.png");
ASSET_MANAGER.queueDownload("./img/DededeFly.png");
ASSET_MANAGER.queueDownload("./img/DededeFall.png");

ASSET_MANAGER.downloadAll(function () {
    var canvas = document.getElementById("gameWorld");
    var ctx = canvas.getContext("2d");

    var gameEngine = new GameEngine();
    gameEngine.init(ctx);
    gameEngine.start();

    var bg = new Background(gameEngine, ASSET_MANAGER.getAsset("./img/background.png"));

    gameEngine.addEntity(bg);
    gameEngine.addEntity(new Swordsman(gameEngine));
    gameEngine.addEntity(new Dedede(gameEngine));


    console.log("All Done!");
});